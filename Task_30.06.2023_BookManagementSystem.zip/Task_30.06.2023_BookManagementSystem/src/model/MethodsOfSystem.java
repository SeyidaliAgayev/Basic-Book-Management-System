package model;

public interface MethodsOfSystem {
    void addBook();
    void displayBook();
    void searchBook();
    void updateBook();
    void removeBook();
}
