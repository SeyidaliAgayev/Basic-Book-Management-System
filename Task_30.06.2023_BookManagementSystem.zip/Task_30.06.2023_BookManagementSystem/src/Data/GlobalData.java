package Data;
import model.Book;
public class GlobalData {
    public static Book[] books;
}
