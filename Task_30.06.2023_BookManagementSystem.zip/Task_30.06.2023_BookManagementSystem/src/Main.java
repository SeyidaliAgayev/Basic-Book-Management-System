import Service.ManagementService;

public class Main {
    public static void main(String[] args) {
        ManagementService.bookManage();
    }
}